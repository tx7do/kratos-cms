<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="scss" scoped>
html,
body {
  margin: 0;
  padding: 0;
}
</style>
