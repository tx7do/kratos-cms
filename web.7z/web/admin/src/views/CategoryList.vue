<template>
  <div>
    <h1>分类列表</h1>
    <el-table :data="items" style="width: 100%">
      <el-table-column prop="id" label="ID" width="480"></el-table-column>
      <el-table-column prop="name" label="分类名称"></el-table-column>
      <el-table-column fixed="right" label="操作" width="180">
        <template v-slot="scope">
          <el-button
              type="text"
              size="small"
              icon="el-icon-edit"
              @click="$router.push(`/categories/edit/${scope.row.id}`)"
          >
            编辑
          </el-button>
          <el-button
              type="text"
              size="small"
              icon="el-icon-delete"
              @click="remove(scope.row.id)"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      items: [],
    }
  },
  methods: {
    async fetch() {
      const res = await this.$http.get('/categories')
      this.items = res.data.items
    },
    async remove(id) {
      this.$confirm('是否确定要删除该分类?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
          .then(async () => {
            await this.$http.delete(`/categories/${id}`)
            this.$message({
              type: 'success',
              message: '删除成功!',
            })
            await this.fetch()
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除',
            })
          })
    },
  },
  created() {
    this.fetch()
  },
}
</script>
