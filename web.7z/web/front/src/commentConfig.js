const commentConfig = {
  topNickName: 'miqilin',
  topParentId: '5ec884e3fe28d35475b43fb3',
}

export default commentConfig
